from django.urls import path
from rest_framework.urlpatterns	 import format_suffix_patterns
from eventsapp import views

urlpatterns = [
    path('student/addStudent/', views.student_list),	
    path('student/allStudents/', views.student_list),	
	path('event/allEvents/', views.event_list),
    path('event/addEvent/', views.event_list),	
    path('event/modifyEvent/<int:pk>', views.event_detail),	
    path('event/deleteEvent/<int:pk>', views.event_detail),	
    path('student/register/', views.register_list),
    path('student/register/<int:pk>', views.student_register_detail),	

]

urlpatterns = format_suffix_patterns(urlpatterns)

