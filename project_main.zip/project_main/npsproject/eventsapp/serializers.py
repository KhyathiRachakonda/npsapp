from rest_framework import serializers
from eventsapp.models import Student, Event, Registration, LANGUAGE_CHOICES, STYLE_CHOICES

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ('id', 'studentName', 'studentEmail', 'Age', 'Grade', 'School')
		
		
class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = ('id', 'eventName', 'eventDescription', 'eventOwner', 'eventStartDate', 'eventEndDate', 'eventDifficulty', 'score')
		
		
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Registration
        fields = '__all__'