from django.apps import AppConfig


class EventsappConfig(AppConfig):
    name = 'eventsapp'
