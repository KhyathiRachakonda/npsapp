from django.db import models

# Create your models here.

from pygments.lexers import get_all_lexers
from pygments.styles import get_all_styles

LEXERS = [item for item in get_all_lexers() if item[1]]
LANGUAGE_CHOICES = sorted([(item[1][0], item[0]) for item in LEXERS])
STYLE_CHOICES = sorted((item, item) for item in get_all_styles())


class Student(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    studentName = models.CharField(max_length=100, blank=False, default='')
    studentEmail = models.CharField(max_length=100, blank=False, default='')
    Age = models.CharField(max_length=2, blank=False, default='')
    Grade =  models.CharField(max_length=2, blank=False, default='')
    School =  models.CharField(max_length=100, blank=True, default='NPS')

    class Meta:
        ordering = ('created',)

		
class Event(models.Model):
    created = models.DateTimeField(auto_now_add=True)
    eventName =  models.CharField(max_length=100, blank=False, default='')
    eventDescription =  models.CharField(max_length=500, blank=False, default='')
    eventOwner =  models.CharField(max_length=100, blank=False, default='')
    eventStartDate =  models.DateField()
    eventEndDate =  models.DateField()
    eventDifficulty =  models.CharField(max_length=100, blank=True, default='')
    score =  models.CharField(max_length=100, blank=True, default='')

    class Meta:
        ordering = ('created',)		

class Registration(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)	

