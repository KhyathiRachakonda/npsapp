from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from eventsapp.models import Student
from eventsapp.models import Event
from eventsapp.models import Registration
from eventsapp.serializers import StudentSerializer
from eventsapp.serializers import EventSerializer
from eventsapp.serializers import RegisterSerializer



@api_view(['GET', 'POST'])
def student_list(request):
    """
    List all code students, or create a new student.
    """
    if request.method == 'GET':
        students = Student.objects.all()
        serializer = StudentSerializer(students, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
		
		
@api_view(['GET', 'PUT', 'DELETE'])
def student_detail(request, pk):
    """
    Retrieve, update or delete a code student.
    """
    try:
        student = Student.objects.get(pk=pk)
    except Student.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = StudentSerializer(student)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = StudentSerializer(student, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        student.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

		
@api_view(['GET', 'POST'])
def event_list(request):
    """
    List all code events, or create a new event.
    """
    if request.method == 'GET':
        events = Event.objects.all()
        EventserializerVar = EventSerializer(events, many=True)
        return Response(EventserializerVar.data)

    elif request.method == 'POST':
        EventserializerVar = EventSerializer(data=request.data)
        if EventserializerVar.is_valid():
            EventserializerVar.save()
            return Response(EventserializerVar.data, status=status.HTTP_201_CREATED)
        return Response(EventserializerVar.errors, status=status.HTTP_400_BAD_REQUEST)
		
		
@api_view(['GET', 'PUT', 'DELETE'])
def event_detail(request, pk):
    """
    Retrieve, update or delete a code event.
    """
    try:
        event = Event.objects.get(pk=pk)
    except Event.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = EventSerializer(event)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = EventSerializer(event, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        event.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
		
		
@api_view(['GET', 'POST'])
def register_list(request):
    """
    List all code events, or create a new event.
    """
    if request.method == 'GET':
        Registrations = Registration.objects.all()
        RegisterserializerVar = RegisterSerializer(Registrations, many=True)
        return Response(RegisterserializerVar.data)

    elif request.method == 'POST':
        RegisterserializerVar = RegisterSerializer(data=request.data)
        if RegisterserializerVar.is_valid():
            RegisterserializerVar.save()
            return Response(RegisterserializerVar.data, status=status.HTTP_201_CREATED)
        return Response(RegisterserializerVar.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def student_register_detail(request, pk):
    """
    Retrieve, update or delete a code event.
    """
    try:
        student = Student.objects.get(pk=pk)
    except Student.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        Registrations = Registration.objects.filter(student=student)
        serializer = RegisterSerializer(Registrations, many=True)
        return Response(serializer.data)
    elif request.method == 'PUT':
        RegisterserializerVar = RegisterSerializer(data=request.data)
        if RegisterserializerVar.is_valid():
            RegisterserializerVar.save()
            return Response(RegisterserializerVar.data, status=status.HTTP_201_CREATED)
        return Response(RegisterserializerVar.errors, status=status.HTTP_400_BAD_REQUEST)